package com.projects;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface Project1Service {
    String addProject(Project1 project);
    List<Project1> getAllProjects();
}
