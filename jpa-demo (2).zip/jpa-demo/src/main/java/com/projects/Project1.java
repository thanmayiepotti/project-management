package com.projects;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="guide")
public class Project1 implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="p_id")
    private int id;

    @Column(name="p_name", nullable=false, length=50)
    private String name;

    @Column(name="p_dept", nullable=false, length=50)
    private String department;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

		// TODO Auto-generated method stub
		
	}

