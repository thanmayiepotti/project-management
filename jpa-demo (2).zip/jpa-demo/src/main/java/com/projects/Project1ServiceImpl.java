package com.projects;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class Project1ServiceImpl implements Project1Service {

    @Override
    public String addProject(Project1 project) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(project);
        em.getTransaction().commit();

        em.close();
        emf.close();
        return "Project Registered Successfully";
    }

    @Override
    public List<Project1> getAllProjects() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT p FROM Project1 p");
        List<Project1> projectList = query.getResultList();

        em.close();
        emf.close();
        return projectList;
    }
}
