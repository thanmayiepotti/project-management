package com.projects;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import java.util.List;

@ManagedBean(name = "emppbean")
@ViewScoped
public class Project1ManagedBean implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private Project1Service service;

    private int id;
    private String name;
    private String department;
    private List<Project1> projectList;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public List<Project1> getProjectList() {
        if (projectList == null) {
            projectList = service.getAllProjects();
        }
        return projectList;
    }

    public String addProject() {
        Project1 project = new Project1();
        project.setId(id);
        project.setName(name);
        project.setDepartment(department);

        service.addProject(project);
        return "viewguide.jsf?faces-redirect=true";
    }
}
