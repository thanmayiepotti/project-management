package com.guide;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface LoginRemote1 {
	public List<String> verifyUserLoginDetails(String email, String password);
	
	public List<String> getPassword(String email);
}
