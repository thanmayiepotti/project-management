package com.guide;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface RegisterRemote1 {
	public List<String> registerUser(LoginEntity1 user);
}
