package com.admin;

import java.util.List;

import javax.ejb.Remote;




@Remote
public interface AdminService 
{
  public Admin checkadminlogin(String username,String password);





}