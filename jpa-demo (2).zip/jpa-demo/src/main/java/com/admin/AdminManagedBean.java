package com.admin;

import java.io.IOException;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@ManagedBean(name = "adminbean", eager = true)
@SessionScoped
public class AdminManagedBean {

    @EJB
    private AdminService adminService;

    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String validateAdminLogin() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ExternalContext externalContext = facesContext.getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();

        if (adminService == null) {
            System.out.println("adminService is null");
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Service error", "Admin service is unavailable"));
            return "error"; // Navigate to error.jsf
        }

        Admin admin = adminService.checkadminlogin(username, password);

        if (admin != null) {
            HttpSession session = request.getSession();
            session.setAttribute("admin", admin);
            return "adminhome.jsf?faces-redirect=true"; // Navigate to adminhome.jsf
        } else {
            facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login failed", "Invalid username or password"));
            return "login"; // Stay on the login page
        }
    }

    public void demo() {
        try {
            // JDBC Code
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "AdminManagedBean [username=" + username + ", password=" + password + "]";
    }
}
