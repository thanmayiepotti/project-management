package com.admin;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class AdminServiceImpl implements AdminService {

    @Override
    public Admin checkadminlogin(String username, String password) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        Query qry = em.createQuery("select a from Admin a where a.username = :username and a.password = :password");
        qry.setParameter("username", username);
        qry.setParameter("password", password);

        Admin admin = null;

        if (!qry.getResultList().isEmpty()) {
            admin = (Admin) qry.getSingleResult();
        }

        em.close();
        emf.close();

        return admin;
    }
}
