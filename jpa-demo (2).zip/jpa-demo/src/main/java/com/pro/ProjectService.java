package com.pro;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface ProjectService {
    String addProject(Project project);
    List<Project> getAllProjects();
    String deleteProject(int id);
    String updateProject(Project project);
    Project viewProjectById(int id);
}
