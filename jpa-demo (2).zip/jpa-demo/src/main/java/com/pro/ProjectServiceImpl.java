package com.pro;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class ProjectServiceImpl implements ProjectService {

    @Override
    public String addProject(Project project) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(project);
        em.getTransaction().commit();

        em.close();
        emf.close();
        return "Project Registered Successfully";
    }

    @Override
    public List<Project> getAllProjects() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT p FROM Project p");
        List<Project> projectList = query.getResultList();

        em.close();
        emf.close();
        return projectList;
    }

    @Override
    public Project viewProjectById(int id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        Project project = em.find(Project.class, id);
        em.close();
        emf.close();
        return project;
    }

    @Override
    public String updateProject(Project project) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Project e = em.find(Project.class, project.getId());
		e.setTitle(project.getTitle());
		e.setDescription(project.getDescription());
		e.setGuide(project.getGuide());
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		return "Project Updated Successfully";
	}
    public Project viewempbyid(int pid) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		
		Project e = em.find(Project.class, pid);
		
		if(e==null)
		{
			em.close();
			emf.close();	
			
			return null;
		}
		em.close();
		emf.close();
		return e;
	}


    @Override
    public String deleteProject(int id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        Project project = em.find(Project.class, id);
        if (project != null) {
            em.remove(project);
            em.getTransaction().commit();
        }

        em.close();
        emf.close();
        return project != null ? "Project Deleted Successfully" : "Project Not Found";
    }
}
