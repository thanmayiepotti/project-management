package com.pro;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;



import java.io.Serializable;
import java.util.List;

@ManagedBean(name = "empbean")
@ViewScoped
public class ProjectManagedBean implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private ProjectService service;

    private int id;
    private String title;
    private String description;
    private String guide;
    private List<Project> projectList;
    private Project selectedProject;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public String getGuide() {
        return guide;
    }

    public void setGuide(String guide) {
        this.guide = guide;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Project> getProjectList() {
        if (projectList == null) {
            projectList = service.getAllProjects();
        }
        return projectList;
    }

    public Project getSelectedProject() {
        return selectedProject;
    }

    public void setSelectedProject(Project selectedProject) {
        this.selectedProject = selectedProject;
    }

    public String addProject() {
        Project project = new Project();
        project.setId(id);
        project.setTitle(title);
        project.setDescription(description);
        project.setGuide(guide);

        service.addProject(project);
        return "viewallprojects.jsf?faces-redirect=true";
    }

    

    public String deleteProject(int id) {
        service.deleteProject(id);
        return "viewallprojects.jsf?faces-redirect=true";
    }
    public String updateProject()
    {
    	Project emp =service.viewProjectById(id);
    	
    	if(emp!=null)
    	{
    			Project e = new Project();
    			e.setId(id);
    			e.setTitle(title);
    			e.setDescription(description);
    			e.setGuide(guide);
    			
    			service.updateProject(e);
    			
    			return "viewallprojects.jsf";
    			
    	}
    	else
    	{
    		//System.out.println("id not found");
    		return "dashboard.jsf";
    	}
    	
    	

    }   
}
