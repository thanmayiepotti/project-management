package com.project;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="project_detail")
public class Projects implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="p_id")
    private int id;

    @Column(name="p_title", nullable=false, length=50)
    private String title;

    @Column(name="p_email", nullable=false, length=50)
    private String email;
    @Column(name="p_guide", nullable=false, length=50)
    private String guide;
    
    public String getGuide() {
		return guide;
	}

	public void setGuide(String guide) {
		this.guide = guide;
	}

	

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
