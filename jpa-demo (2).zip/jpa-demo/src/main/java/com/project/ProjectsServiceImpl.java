package com.project;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class ProjectsServiceImpl implements ProjectsService {

    @Override
    public String addProject(Projects project) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(project);
        em.getTransaction().commit();

        em.close();
        emf.close();
        return "Project Registered Successfully";
    }

    @Override
    public List<Projects> getAllProjects() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT p FROM Projects p");
        List<Projects> projectLists = query.getResultList();

        em.close();
        emf.close();
        return projectLists;
    }
}
