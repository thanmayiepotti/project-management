package com.project;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import java.util.List;

@ManagedBean(name = "empsbean")
@ViewScoped
public class ProjectsManagedBean implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private ProjectsService service;

    private int id;
    private String title;
    private String email;
    private String guide;
    
    public String getGuide() {
		return guide;
	}

	public void setGuide(String guide) {
		this.guide = guide;
	}
    private List<Projects> projectLists;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Projects> getProjectLists() {
        if (projectLists == null) {
            projectLists = service.getAllProjects();
        }
        return projectLists;
    }

    public String addProject() {
        Projects project = new Projects();
        project.setId(id);
        project.setTitle(title);
        project.setEmail(email);
        project.setGuide(guide);

        service.addProject(project);
        return "SelectedProjectView.jsf?faces-redirect=true";
    }
}
