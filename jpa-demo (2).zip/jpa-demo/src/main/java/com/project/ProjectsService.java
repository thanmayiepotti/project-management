package com.project;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface ProjectsService {
    String addProject(Projects project);
    List<Projects> getAllProjects();
}
