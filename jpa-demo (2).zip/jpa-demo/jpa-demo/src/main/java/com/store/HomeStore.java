package com.store;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "homeStore", eager = true)
@SessionScoped
public class HomeStore implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private boolean isLoggedIn = false;
    private String loginToken = "";
    private String userEmail = null;
    private String userName = null;
    private String SelectedProject = null;
    private boolean showMainLoader = false;
    private String mainLoaderMessage = "";
    
    // New fields for salary and savings
    private double salary;
    private double savings;

    // Getters and Setters for the new fields
     
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getSavings() {
        return savings;
    }

    public void setSavings(double savings) {
        this.savings = savings;
    }

    // Method to add salary to savings
    public void addSalary() {
        this.savings += this.salary;
        this.salary = 0; // Reset salary input after adding to savings
    }

    // Existing methods and fields
    public String getMainLoaderMessage() {
        return mainLoaderMessage;
    }

    public void setMainLoaderMessage(String mainLoaderMessage) {
        this.mainLoaderMessage = mainLoaderMessage;
    }

    public boolean isShowMainLoader() {
        return showMainLoader;
    }

    public void setShowMainLoader(boolean showMainLoader) {
        this.showMainLoader = showMainLoader;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    } 

    @PostConstruct
    public void init() {
        System.out.println("HomeStore post-construct initialized");
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public boolean getIsLoggedIn() {
        return isLoggedIn;
    }

    public void setIsLoggedIn(boolean isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
    }

    public String getLoginToken() {
        return loginToken;
    }

    public void setLoginToken(String loginToken) {
        this.loginToken = loginToken;
    }

    public String openDashboard() {
        if(isLoggedIn)
            return "dashboard.jsf";
        else
            return "login.jsf";
    }

    public String openAccountProfile() {
        if(isLoggedIn) {
            return "account.jsf";
        }
        else
            return "login.jsf";
    }
}
